﻿using System.Collections;

namespace gokcesuterme;

class Program
{
    //init permutation table
    private static readonly int[] IP = new int[]
    {
        58, 50, 42, 34, 26, 18, 10, 2,
        60, 52, 44, 36, 28, 20, 12, 4,
        62, 54, 46, 38, 30, 22, 14, 6,
        64, 56, 48, 40, 32, 24, 16, 8,
        57, 49, 41, 33, 25, 17, 9,  1,
        59, 51, 43, 35, 27, 19, 11, 3,
        61, 53, 45, 37, 29, 21, 13, 5,
        63, 55, 47, 39, 31, 23, 15, 7
    };
    // final permutation table, reverse of the init permutation
    private static readonly int[] FP = new int[]
    {
        40, 8, 48, 16, 56, 24, 64, 32,
        39, 7, 47, 15, 55, 23, 63, 31,
        38, 6, 46, 14, 54, 22, 62, 30,
        37, 5, 45, 13, 53, 21, 61, 29,
        36, 4, 44, 12, 52, 20, 60, 28,
        35, 3, 43, 11, 51, 19, 59, 27,
        34, 2, 42, 10, 50, 18, 58, 26,
        33, 1, 41, 9,  49, 17, 57, 25
    };
    /*
     * 
- Sample plaintext (64-bit): `0010101010111101001000110110001001100110011110000110100101100110`
- Sample key (64-bit): `0001001100110100010101110111100110011011101111001101111111110001`
- Sample IV (64-bit for CTR mode): `1100110010101100101010101100110010101010110011001010101011001100`
     */
    private static BitArray PerformPermutation(BitArray text, int[] permutationTable)
    {
        if (text.Length != 64)
        {
            throw new ArgumentException("Input must be a 64-bit BitArray.");
        }
        if (permutationTable.Length != 64)
        {
            throw new ArgumentException("Permutation table must have 64 entries.");
        }

        BitArray output = new BitArray(64);
        for (int i = 0; i < permutationTable.Length; i++)
        {
            output[i] = text[permutationTable[i] - 1]; // Adjust for zero-based indexing
        }
        return output;
    }

    
    static void Main(string[] args)
    {
        while (true)
        {
            Console.WriteLine("Choose mode: Regular DES (r) or CTR mode (c) or (x) to exit:");
            string mode = Console.ReadLine().ToLower();
            if (mode == "r") // Regular DES encryption/decryption
            {
                Console.WriteLine("Do you want to encrypt or decrypt? (e/d):");
                string action = Console.ReadLine().ToLower();

                if (action == "e") // perform encryption
                {
                    Console.WriteLine("Enter plaintext (64-bit binary string):");
                    string plaintextStr = Console.ReadLine();
                    BitArray plaintext = ConvertStringToBitArray(plaintextStr, 64);

                    Console.WriteLine("Enter key (64-bit binary string):");
                    string keyStr = Console.ReadLine();
                    BitArray key = ConvertStringToBitArray(keyStr, 64);
                    // Perform encryption
                    BitArray ciphertext = Encrypt(plaintext, key);
                    Console.WriteLine("Encrypted text:");
                    Console.WriteLine(BitArrayToString(ciphertext));
                }
                else if (action == "d")
                {

                    Console.WriteLine("Enter ciphertext (64-bit binary string):");
                    string ciphertextStr = Console.ReadLine();
                    BitArray ciphertext = ConvertStringToBitArray(ciphertextStr, 64);

                    Console.WriteLine("Enter key (64-bit binary string):");
                    string keyStr = Console.ReadLine();
                    BitArray key = ConvertStringToBitArray(keyStr, 64);

                    BitArray plaintext = Decrypt(ciphertext, key);

                    Console.WriteLine("Decrypted text:");
                    Console.WriteLine(BitArrayToString(plaintext));
                }
                else
                {
                    Console.WriteLine("Invalid choice. Please enter 'e' for encryption or 'd' for decryption.");
                }
    
            }

            else if (mode == "c") // CTR mode
            {
                Console.WriteLine("Enter IV as a 64-bit binary string:");
                string ivBinaryString = Console.ReadLine();
                BitArray ivBitArray;

                try
                {
                    ivBitArray = ConvertStringToBitArray(ivBinaryString, 64);
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine(ex.Message);
                    continue; // Prompt the user to enter the IV again
                }

                Console.WriteLine("Do you want to encrypt or decrypt? (e/d):");
                string action = Console.ReadLine().ToLower();

                if (action == "e" || action == "d") 
                {
                    Console.WriteLine("Enter text (64-bit string):");
                    string textStr = Console.ReadLine();
                    BitArray textBitArray = ConvertStringToBitArray(textStr, 64);

                    Console.WriteLine("Enter key (64-bit string):");
                    string keyStr = Console.ReadLine();
                    BitArray keyBitArray = ConvertStringToBitArray(keyStr, 64);

                    BitArray result = modeCTR(textBitArray, keyBitArray, ivBitArray);
                    Console.WriteLine($"{(action == "e" ? "Encrypted" : "Decrypted")} text using CTR mode:");
                    Console.WriteLine(BitArrayToString(result));
                }
                else
                {
                    Console.WriteLine("Invalid choice. Please enter 'e' for encryption or 'd' for decryption.");
                }
            }
            else if (mode == "x") // Exit the program
            {
                Console.WriteLine("Exiting...");
                break;
            }
            else
            {
                Console.WriteLine("Invalid mode selected.");
            }
            
        }
    }

    static BitArray ConvertStringToBitArray(string binaryString, int expectedLength)
    {
        if (binaryString.Length != expectedLength)
        {
            throw new ArgumentException($"Input must be a {expectedLength}-bit binary string.");
        }

        BitArray bitArray = new BitArray(expectedLength);
        for (int i = 0; i < binaryString.Length; i++)
        {
            bitArray[i] = binaryString[i] == '1';
        }
        return bitArray;
    }

    static string BitArrayToString(BitArray bitArray)
    {
        char[] charArray = new char[bitArray.Count];
        for (int i = 0; i < bitArray.Count; i++)
        {
            charArray[i] = bitArray[i] ? '1' : '0';
        }
        return new string(charArray);
    }

    static BitArray Encrypt(BitArray plaintext, BitArray key)
    {
        BitArray permutedPlaintext = PerformPermutation(plaintext,IP); 
        BitArray result = permutedPlaintext;
        for (int i = 0; i < 16; i++)
        {
            BitArray subKey = Key.KeyGenerator(key, i); 
            result = Des.DesRounds(result, subKey, i);
        }
        BitArray ciphertext = PerformPermutation(result,FP); 
        
        return ciphertext;
    }

    static BitArray Decrypt(BitArray cipherText, BitArray key)
    {
        BitArray text = PerformPermutation(cipherText, IP);
        int i = 0;
        for (int round = 15; round >= 0; round--)
        {
            // For decryption, subkeys are applied in reverse order
            BitArray subKey = Key.KeyGenerator(key, round);
            text = Des.DesRounds(text, subKey, i);
            i++;
        }
        BitArray plainText =  PerformPermutation(text, FP);
        return plainText;
    }
    private static BitArray modeCTR(BitArray inputData, BitArray key, BitArray iv)
    {
        BitArray counter = new BitArray(iv); // Initialize the counter with the user iv 
        BitArray outputData = new BitArray(inputData.Length);

        // Encrypt the counter
        BitArray encryptedCounter = Encrypt(counter, key);

        // encrypted counter XOR the ciphertext or plaintext (inputData)
        for (int i = 0; i < inputData.Length; i++)
        {
            outputData[i] = encryptedCounter[i] ^ inputData[i];
        }

        IncrementCounter(ref counter);

        return outputData;
    }

  
    private static void IncrementCounter(ref BitArray counter)
    {
        for (int i = counter.Count - 1; i >= 0; i--)
        {
            if (counter[i])
            {
                counter[i] = false;
            }
            else
            {
                counter[i] = true; 
                break;
            }
        }
    }
    
}


