using System.Collections;
namespace gokcesuterme;
public class Key
{
    private static BitArray PermuteKey(BitArray inputKey, int[] permutationTable)
    {
        BitArray permutedKey = new BitArray(permutationTable.Length); // Create a new bit array based on the permutation table's length
        
        for (int i = 0; i < permutationTable.Length; i++)
        {
            permutedKey[i] = inputKey[permutationTable[i] - 1]; // Permute the bits according to the table
        }
        
        return permutedKey;
    }

    private static BitArray LeftShift(BitArray bits, int shiftAmount)
    {
        int length = bits.Length; 
        BitArray shifted = new BitArray(length);
        for (int i = 0; i < length; i++)
        {
            int index = (i + shiftAmount) % length; 
            shifted[index] = bits[i];
        }

        return shifted;
    }
        
    public static BitArray KeyGenerator(BitArray inputKey, int round)
    {
        BitArray permutedKey = new BitArray(56);
        BitArray c = new BitArray(28);
        BitArray d = new BitArray(28);
        // PC-1 Table 
        int[] pc1 =
        {
            57, 49, 41, 33, 25, 17, 9,
            1, 58, 50, 42, 34, 26, 18,
            10, 2, 59, 51, 43, 35, 27,
            19, 11, 3, 60, 52, 44, 36,
            63, 55, 47, 39, 31, 23, 15,
            7, 62, 54, 46, 38, 30, 22,
            14, 6, 61, 53, 45, 37, 29,
            21, 13, 5, 28, 20, 12, 4
        };

        // PC-2 Table 
        int[] pc2 =
        {
            14, 17, 11, 24, 1, 5,
            3, 28, 15, 6, 21, 10,
            23, 19, 12, 4, 26, 8,
            16, 7, 27, 20, 13, 2,
            41, 52, 31, 37, 47, 55,
            30, 40, 51, 45, 33, 48,
            44, 49, 39, 56, 34, 53,
            46, 42, 50, 36, 29, 32
        };

        if (round == 0)
        {
            permutedKey = PermuteKey(inputKey, pc1);
        }
        else
        {
            permutedKey = inputKey;
        }

        for (int i = 0; i < 28; i++)
        {
            c[i] = permutedKey[i];
            d[i] = permutedKey[i + 28];
        }

        int shiftAmount = (round == 0 || round == 1 || round == 8 || round == 15) ? 1 : 2;
        c = LeftShift(c, shiftAmount);
        d = LeftShift(d, shiftAmount);

        BitArray combined = new BitArray(56);
        for (int i = 0; i < 28; i++)
        {
            combined[i] = c[i];           
            combined[i + 28] = d[i];       
        }

        BitArray k = new BitArray(pc2.Length); // PC2.Length should be 48
        for (int i = 0; i < pc2.Length; i++)
        {
            k[i] = combined[pc2[i] - 1]; // -1 for zero based index
        }

        return k;
    }
}